const express = require("express")
const path = require("path")
const app = express()
const PORT = process.env.PORT || 3000

// Serve static files
app.use(express.static("public"))
app.use(express.json())

// Farcaster manifest redirect
app.get("/.well-known/farcaster.json", (req, res) => {
  res.json({
    accountAssociation: {
      header: "eyJmaWQiOjEsInR5cGUiOiJjdXN0b2R5Iiwia2V5IjoiMHg0ODY5NGE2NzJkNjc2YzY5NjI2NTc3Mjc0NzkyZTY1NzQ2OCJ9",
      payload: "eyJkb21haW4iOiJ5b3VyLWRvbWFpbi5jb20ifQ",
      signature: "MHg...",
    },
  })
})

// Main mini app route
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"))
})

app.get("/api/miniapp-config", (req, res) => {
  const baseUrl = process.env.BASE_URL || `${req.protocol}://${req.get("host")}`

  res.json({
    version: "1",
    imageUrl: `${baseUrl}/snake-preview.jpg`,
    button: {
      title: "Play Snake",
      action: {
        type: "launch_frame",
        url: baseUrl,
        name: "Retro Snake",
        splashImageUrl: `${baseUrl}/snake-splash.jpg`,
        splashBackgroundColor: "#000000",
      },
    },
  })
})

// API endpoint for scores (simplified for demo)
app.post("/api/score", (req, res) => {
  const { score, fid } = req.body
  // In a real app, you'd save this to a database
  console.log(`Player ${fid} scored ${score}`)
  res.json({ success: true, score })
})

app.get("/api/leaderboard", (req, res) => {
  // Mock leaderboard data
  const leaderboard = [
    { fid: "12345", username: "player1", score: 150 },
    { fid: "67890", username: "player2", score: 120 },
    { fid: "11111", username: "player3", score: 100 },
  ]
  res.json(leaderboard)
})

app.get("*", (req, res) => {
  // If it's an API route, return JSON error
  if (req.path.startsWith("/api/")) {
    res.status(404).json({ error: "API endpoint not found" })
  } else {
    // For all other routes, serve the main app
    res.sendFile(path.join(__dirname, "public", "index.html"))
  }
})

app.use((err, req, res, next) => {
  console.error("Server error:", err)
  res.status(500).json({ error: "Internal server error" })
})

app.listen(PORT, () => {
  console.log(`Farcaster Snake Mini App running on port ${PORT}`)
})

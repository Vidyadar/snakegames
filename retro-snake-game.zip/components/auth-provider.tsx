"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import type { User } from "firebase/auth"
import { signInAnonymous, onAuthStateChange, generateDisplayName } from "@/lib/auth"
import { isFirebaseConfigured } from "@/lib/firebase"

interface AuthContextType {
  user: User | null
  displayName: string
  loading: boolean
  signIn: () => Promise<void>
  isOffline: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [displayName, setDisplayName] = useState("")
  const [isOffline, setIsOffline] = useState(!isFirebaseConfigured())

  const signIn = async () => {
    if (isOffline) {
      // Generate offline user
      const offlineUser = {
        uid: localStorage.getItem("offlineUserId") || `offline_${Math.random().toString(36).substr(2, 9)}`,
        isAnonymous: true,
      } as User

      if (!localStorage.getItem("offlineUserId")) {
        localStorage.setItem("offlineUserId", offlineUser.uid)
      }

      setUser(offlineUser)
      const name = generateDisplayName(offlineUser.uid)
      setDisplayName(name)
      localStorage.setItem("snakeDisplayName", name)
      return
    }

    try {
      const user = await signInAnonymous()
      if (user) {
        const name = generateDisplayName(user.uid)
        setDisplayName(name)
        localStorage.setItem("snakeDisplayName", name)
      }
    } catch (error) {
      console.error("Auth failed, switching to offline mode:", error)
      setIsOffline(true)
      await signIn() // Retry in offline mode
    }
  }

  useEffect(() => {
    if (isOffline) {
      // Handle offline mode
      const offlineUserId = localStorage.getItem("offlineUserId")
      if (offlineUserId) {
        const offlineUser = { uid: offlineUserId, isAnonymous: true } as User
        setUser(offlineUser)

        let name = localStorage.getItem("snakeDisplayName")
        if (!name) {
          name = generateDisplayName(offlineUserId)
          localStorage.setItem("snakeDisplayName", name)
        }
        setDisplayName(name)
      } else {
        signIn()
      }
      setLoading(false)
      return
    }

    // Handle Firebase mode
    try {
      const unsubscribe = onAuthStateChange((user) => {
        setUser(user)

        if (user) {
          let name = localStorage.getItem("snakeDisplayName")
          if (!name) {
            name = generateDisplayName(user.uid)
            localStorage.setItem("snakeDisplayName", name)
          }
          setDisplayName(name)
        } else {
          setDisplayName("")
          signIn()
        }

        setLoading(false)
      })

      return () => unsubscribe()
    } catch (error) {
      console.error("Firebase auth setup failed, switching to offline mode:", error)
      setIsOffline(true)
      setLoading(false)
    }
  }, [isOffline])

  return (
    <AuthContext.Provider value={{ user, displayName, loading, signIn, isOffline }}>{children}</AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

import { signInAnonymously, onAuthStateChanged, type User } from "firebase/auth"
import { auth, isFirebaseConfigured } from "./firebase"

// Sign in anonymously to get a unique user ID
export const signInAnonymous = async (): Promise<User | null> => {
  if (!isFirebaseConfigured() || !auth) {
    throw new Error("Firebase not configured")
  }

  try {
    const result = await signInAnonymously(auth)
    return result.user
  } catch (error) {
    console.error("Error signing in anonymously:", error)
    throw error
  }
}

// Listen for authentication state changes
export const onAuthStateChange = (callback: (user: User | null) => void) => {
  if (!isFirebaseConfigured() || !auth) {
    throw new Error("Firebase not configured")
  }

  return onAuthStateChanged(auth, callback)
}

// Get current user
export const getCurrentUser = (): User | null => {
  if (!auth) return null
  return auth.currentUser
}

// Generate a display name for anonymous users
export const generateDisplayName = (uid: string): string => {
  const adjectives = ["Swift", "Clever", "Mighty", "Quick", "Bold", "Sharp", "Brave", "Smart"]
  const animals = ["Snake", "Viper", "Cobra", "Python", "Adder", "Mamba", "Boa", "Asp"]

  // Use UID to generate consistent name
  const adjIndex = uid.charCodeAt(0) % adjectives.length
  const animalIndex = uid.charCodeAt(1) % animals.length
  const number = uid.slice(-3)

  return `${adjectives[adjIndex]}${animals[animalIndex]}${number}`
}
